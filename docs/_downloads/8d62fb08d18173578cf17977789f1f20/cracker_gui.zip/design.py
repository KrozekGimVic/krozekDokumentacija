# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'crack.ui'
#
# Created by: PyQt5 UI code generator 5.8
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setEnabled(True)
        MainWindow.resize(437, 145)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        MainWindow.setWindowIcon(icon)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.path_textbox = QtWidgets.QLineEdit(self.centralwidget)
        self.path_textbox.setGeometry(QtCore.QRect(131, 23, 181, 32))
        self.path_textbox.setObjectName("path_textbox")
        self.crack_button = QtWidgets.QPushButton(self.centralwidget)
        self.crack_button.setGeometry(QtCore.QRect(330, 22, 88, 31))
        self.crack_button.setAutoDefault(False)
        self.crack_button.setObjectName("crack_button")
        self.path_label = QtWidgets.QLabel(self.centralwidget)
        self.path_label.setGeometry(QtCore.QRect(8, 30, 121, 20))
        self.path_label.setObjectName("path_label")
        self.progress_bar = QtWidgets.QProgressBar(self.centralwidget)
        self.progress_bar.setGeometry(QtCore.QRect(10, 70, 411, 16))
        self.progress_bar.setProperty("value", 0)
        self.progress_bar.setObjectName("progress_bar")
        self.pass_textbox = QtWidgets.QLineEdit(self.centralwidget)
        self.pass_textbox.setGeometry(QtCore.QRect(80, 100, 113, 32))
        self.pass_textbox.setObjectName("pass_textbox")
        self.pass_label = QtWidgets.QLabel(self.centralwidget)
        self.pass_label.setGeometry(QtCore.QRect(10, 110, 71, 18))
        self.pass_label.setObjectName("pass_label")
        MainWindow.setCentralWidget(self.centralwidget)
        self.actionQuit = QtWidgets.QAction(MainWindow)
        self.actionQuit.setObjectName("actionQuit")

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "P4ssw0rdCr4ck3r"))
        self.path_textbox.setText(_translate("MainWindow", "brute_force"))
        self.crack_button.setText(_translate("MainWindow", "Crack"))
        self.path_label.setText(_translate("MainWindow", "Path to application:"))
        self.pass_label.setText(_translate("MainWindow", "Password:"))
        self.actionQuit.setText(_translate("MainWindow", "&Quit (CTRL+Q or ESC)"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

