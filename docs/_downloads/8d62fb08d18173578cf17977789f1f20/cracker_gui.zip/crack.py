from PyQt5 import QtGui, QtCore, QtWidgets
import design
import sys
import time
import string
import itertools
import subprocess
import os
import multiprocessing
import functools

def try_password(guess, filename):
    # if found: return
    guess = ''.join(guess) + '\n'
    if filename[:2] != './':
        filename = './' + filename
    out = subprocess.run([filename], stdout=subprocess.PIPE, input=guess.encode('ascii'))
    out = out.stdout.decode('ascii')
    if out != 'nepravilno\n':
        return guess.strip()
    return ''


class Worker(QtCore.QObject):
    stepIncreased = QtCore.pyqtSignal(int)
    cracked = QtCore.pyqtSignal(str)

    def __init__(self):
        super(Worker, self).__init__()

    def do_work(self, path):
        length = 0
        while True:
            print(length)
            total = len(string.ascii_lowercase) ** length
            count = 0
            found = multiprocessing.Value('b', False)

            p = multiprocessing.Pool(8)
            for i in p.imap_unordered(functools.partial(try_password, filename=path),
                                      itertools.product(string.ascii_lowercase, repeat=length)):
                self.stepIncreased.emit((100 * count) // total)
                if i != '':
                    found.value = True
                    self.cracked.emit(i)
                    return
                count += 1
            length += 1


class Ripper(QtWidgets.QMainWindow, design.Ui_MainWindow):

    startCracking = QtCore.pyqtSignal(str)

    def __init__(self):
        super(self.__class__, self).__init__()
        self.setupUi(self)

        self.worker_thread = QtCore.QThread()
        self.worker_thread.start()

        self.worker = Worker()
        self.worker.moveToThread(self.worker_thread)
        self.worker.stepIncreased.connect(self.progress_bar.setValue)
        self.worker.cracked.connect(self.after_crack)

        self.crack_button.clicked.connect(self.before_crack)
        self.startCracking.connect(self.worker.do_work)

    def before_crack(self):
        path = self.path_textbox.text()
        if not os.path.isfile(path):
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Critical)
            msg.setText("No such file or directory.")
            msg.setWindowTitle("MessageBox demo")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
            msg.exec_()
            return
        if not os.access(path, os.X_OK):
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Critical)
            msg.setText("The file exists, but is not executable.")
            msg.setWindowTitle("MessageBox demo")
            msg.setStandardButtons(QtWidgets.QMessageBox.Ok | QtWidgets.QMessageBox.Cancel)
            msg.exec_()
            return
        self.crack_button.setEnabled(False)
        self.startCracking.emit(path)

    def after_crack(self, password):
        self.pass_textbox.setText(password)
        self.crack_button.setEnabled(True)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    form = Ripper()
    form.move(500, 200)
    form.show()
    app.exec_()


